﻿namespace RegistrationServices.BusinessLayer
{
    public class Class1
    {
    }
}
