using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace RegistrationServices.BusinessLayerTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod()]
        public void TestMethod1()
        {
        }
    }
}
