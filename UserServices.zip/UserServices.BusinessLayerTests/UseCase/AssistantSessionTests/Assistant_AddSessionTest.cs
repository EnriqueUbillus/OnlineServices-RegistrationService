﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using RegistrationServices.BusinessLayer.UseCase;
using Moq;
using OnlineServices.Shared.Exceptions;
using RegistrationServices.BusinessLayer;
using OnlineServices.Shared.RegistrationServices.Interface;
using OnlineServices.Shared.RegistrationServices.TransferObject;

namespace RegistrationServices.BusinessLayerTests.UseCase
{
    [TestClass]
    public class Assistant_AddSessionTest
    {
        Mock<IRSUnitOfWork> MockUofW = new Mock<IRSUnitOfWork>();
        Mock<IRSSessionRepository> MockSessionRepository = new Mock<IRSSessionRepository>();

        [TestMethod]
        public void AddSession_ThrowException_WhenSessionIDisDiferentThanZero()
        {
            //ARRANGE
            var assistant = new AssistantRole( (new Mock<IRSUnitOfWork>()).Object   );
            var sessionToAdd = new SessionTO { ID = 1, Course = null, TeacherName = null  };

            //ASSERT
            Assert.ThrowsException<Exception>(  () => assistant.AddSession(sessionToAdd)  );
        }

        //[TestMethod]
        //public void AddSession_ThrowIsNullOrWhiteSpaceException_WhenSessionNameIsAnEmptyString()
        //{
        //    //ARRANGE
        //    var userNameWhiteSpace = new UserTO { ID = 0, Name = "" };
        //    var userNameNull = new UserTO { ID = 0, Name = null};

        //    var mockUofW = new Mock<IRSUnitOfWork>();
        //    var assistant = new AssistantRole(mockUofW.Object);

        //    //ASSERT
        //    Assert.ThrowsException<IsNullOrWhiteSpaceException>(() => assistant.AddUser(userNameWhiteSpace));
        //    Assert.ThrowsException<IsNullOrWhiteSpaceException>(() => assistant.AddUser(userNameNull));
        //}

        //[TestMethod]
        //public void AddSession_ThrowException_WhenLoggedUserIsNull()
        //{
        //    //ARRANGE
        //    var assistant = new AssistantRole(MockUofW.Object);

        //    //ASSERT
        //    Assert.ThrowsException<LoggedException>( () => assistant.AddUser(null)  );
        //}

        [TestMethod]
        public void AddSession_NewSession_Test()
        {
            //ARRANGE
            var newSession = new SessionTO { ID = 0,  Course = null, TeacherName = null };

            MockSessionRepository.Setup(x => x.Add(It.IsAny<SessionTO>()));
            var mockUofW = new Mock<IRSUnitOfWork>();
            mockUofW.Setup(x => x.SessionRepository).Returns(MockSessionRepository.Object);

            var assistant = new AssistantRole(mockUofW.Object);

            //ASSERT
            Assert.IsTrue(assistant.AddSession(newSession));
        }

        [TestMethod]
        public void AddUser_UserRepositoryIsCalledOnce_WhenAValidUserIsProvidedAndAddInDB()
        {
            //ARRANGE
            MockSessionRepository.Setup( x => x.Add(It.IsAny<SessionTO>()) );
            MockUofW.Setup( x => x.SessionRepository).Returns(MockSessionRepository.Object);

            var ass = new AssistantRole(MockUofW.Object);
            var newSession = new SessionTO { ID = 0,  Course = null, TeacherName = null };

            //ACT
            ass.AddSession(newSession);
            MockSessionRepository.Verify( x => x.Add(It.IsAny<SessionTO>()), Times.Once );
        }
    }
}
