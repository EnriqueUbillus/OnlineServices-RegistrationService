﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Text;
using RegistrationServices.BusinessLayer.UseCase;
using OnlineServices.Shared.RegistrationServices.TransferObject;
using Moq;
using OnlineServices.Shared.RegistrationServices.Interface;
using System.Linq;

namespace RegistrationServices.BusinessLayerTests.UseCase
{
    [TestClass]
    public class Assistant_GetSessionsTest
    {
        Mock<IRSUnitOfWork> MockUofW = new Mock<IRSUnitOfWork>();
        Mock<IRSUserRepository> MockUserRepository = new Mock<IRSUserRepository>();

        public static List<UserTO> UserList()
        {
            return new List<UserTO>
            {
                new UserTO { ID=1, Name="Suplier1"},
                new UserTO { ID=2, Name="Suplier3"},
                new UserTO { ID=3, Name="Suplier3"}
            };
        }

        [TestMethod]
        public void GetUsers_ReturnsAllUsersFromDB()
        {
            //ARRANGE
            MockUserRepository.Setup( x=>x.GetAll()).Returns(UserList);
            MockUofW.Setup(x => x.UserRepository).Returns(MockUserRepository.Object);

            var ass = new AssistantRole(MockUofW.Object);

            //ACT
            var users = ass.GetUsers();
            
            //ASSERT
            Assert.AreEqual(UserList().Count, users.Count );
            Assert.AreEqual(3, users.Count );
        }

        [TestMethod]
        public void GetUsers_UserRepositoryIsCalledOnce()
        {
            //ARRANGE
            MockUserRepository.Setup( x => x.GetAll()).Returns(UserList);
            MockUofW.Setup( x => x.UserRepository ).Returns(MockUserRepository.Object);

            var ass = new AssistantRole(MockUofW.Object);

            //ACT
            var usersAll = ass.GetUsers();

            //ASSERT
            MockUserRepository.Verify(x=>x.GetAll(), Times.Once);

        }
        //===============================================================================================================
        /// <summary>
        /// Get UserById Tests
        /// </summary>

        [TestMethod]
        public void GetUser_NullReferenceException_WhenUserIDisZero()
        {
            //ARRANGE
            int userId = 0;
            var Assistante = new AssistantRole((new Mock<IRSUnitOfWork>()).Object);

            //ASSERT
            Assert.ThrowsException<NullReferenceException>(() => Assistante.GetUserById(userId));
        }

        [TestMethod]
        public void GetUser_ReturnsUserByIDFromDB()
        {
            //ARRANGE
            int userId = 1;
            MockUserRepository.Setup(x => x.GetByID(userId)).Returns(UserList().FirstOrDefault(x=>x.ID == userId));
            MockUofW.Setup(x => x.UserRepository).Returns(MockUserRepository.Object);

            var ass = new AssistantRole(MockUofW.Object);

            //ACT
            var userById = ass.GetUserById(userId);

            //ASSERT
            Assert.AreEqual(userId ,userById.ID);
        }

        [TestMethod]
        public void GetUser_ReturnsNull_WhenUserDoesNotExist()
        {
            //ARRANGE
            int userId = 10000;
            MockUserRepository.Setup(x => x.GetByID(userId)).Returns(UserList().FirstOrDefault(x => x.ID == userId));
            MockUofW.Setup(x => x.UserRepository).Returns(MockUserRepository.Object);

            var ass = new AssistantRole(MockUofW.Object);

            //ACT
            var userById = ass.GetUserById(userId);

            //ASSERT
            Assert.IsNull(userById);
        }


        
    }
}
